"""Basic tests for SynthID Remover"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import unittest
import numpy as np
from PIL import Image

from src.utils.image import (
    calculate_adaptive_denoise, canny_edge_detect, 
    numpy_to_tensor, tensor_to_numpy, composite_images
)
from config import APP_NAME, APP_VERSION, DEFAULTS


class TestConfig(unittest.TestCase):
    def test_app_name(self):
        self.assertEqual(APP_NAME, "SynthID Remover")

    def test_version(self):
        self.assertEqual(APP_VERSION, "2.0.0")

    def test_defaults(self):
        self.assertIn("positive_prompt", DEFAULTS)
        self.assertIn("negative_prompt", DEFAULTS)
        self.assertIn("denoise_auto", DEFAULTS)


class TestImageUtils(unittest.TestCase):
    def test_adaptive_denoise_512(self):
        img = np.zeros((512, 512, 3), dtype=np.uint8)
        denoise = calculate_adaptive_denoise(img)
        self.assertAlmostEqual(denoise, 0.08, delta=0.02)

    def test_adaptive_denoise_1024(self):
        img = np.zeros((1024, 1024, 3), dtype=np.uint8)
        denoise = calculate_adaptive_denoise(img)
        self.assertAlmostEqual(denoise, 0.12, delta=0.02)

    def test_adaptive_denoise_2048(self):
        img = np.zeros((2048, 2048, 3), dtype=np.uint8)
        denoise = calculate_adaptive_denoise(img)
        self.assertAlmostEqual(denoise, 0.15, delta=0.02)

    def test_canny_shape(self):
        img = np.random.randint(0, 255, (256, 256, 3), dtype=np.uint8)
        edges = canny_edge_detect(img)
        self.assertEqual(edges.shape, (256, 256, 3))

    def test_tensor_roundtrip(self):
        img = np.random.randint(0, 255, (128, 128, 3), dtype=np.uint8)
        tensor = numpy_to_tensor(img, "cpu")
        self.assertEqual(tensor.shape, (1, 3, 128, 128))
        back = tensor_to_numpy(tensor)
        self.assertEqual(back.shape, (128, 128, 3))

    def test_composite(self):
        bg = np.ones((100, 100, 3), dtype=np.uint8) * 100
        fg = np.ones((50, 50, 3), dtype=np.uint8) * 200
        mask = np.ones((50, 50), dtype=np.uint8) * 128
        bbox = (10, 10, 60, 60)
        result = composite_images(bg, fg, mask, bbox)
        self.assertEqual(result.shape, (100, 100, 3))


class TestPipelineConfig(unittest.TestCase):
    def test_pipeline_config_creation(self):
        from src.pipeline.core import PipelineConfig
        config = PipelineConfig(image_path="test.png")
        self.assertEqual(config.image_path, "test.png")
        self.assertTrue(config.denoise_auto)
        self.assertTrue(config.face_enhancement)


class TestModelManager(unittest.TestCase):
    def test_missing_models(self):
        from src.models.loader import ModelManager
        from config import MODEL_PATHS
        mm = ModelManager(MODEL_PATHS, "cpu")
        missing = mm.missing_models
        # All models should be missing in a fresh checkout
        self.assertTrue(len(missing) > 0)


if __name__ == "__main__":
    unittest.main()
