"""Main GUI for SynthID Remover Desktop App

Features:
- Drag-and-drop image loading
- Before/After comparison slider
- Real-time stage progress tracking
- Persistent user settings
- Keyboard shortcuts
- Model status display
"""
import os
import sys
import threading
import logging
from pathlib import Path
from typing import Optional
from PIL import Image, ImageTk
import customtkinter as ctk

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from config import APP_NAME, APP_VERSION, MODEL_PATHS, OUTPUT_DIR, INPUT_DIR, DEFAULTS
from src.models.loader import ModelManager
from src.pipeline.core import SynthIDPipeline, PipelineConfig, PipelineResult
from src.gui.widgets import DragDropImage, BeforeAfterSlider, ProgressCard, ModelStatusWidget
from src.gui.settings import SettingsManager, UserSettings
from src.utils.helpers import get_system_info, setup_logging
from src.utils.validators import validate_image_path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


class SynthIDRemoverApp(ctk.CTk):
    """Main application window with advanced widgets and persistent settings."""

    def __init__(self):
        super().__init__()

        # Settings manager
        self.settings_manager = SettingsManager()
        self.settings = self.settings_manager.settings

        # Window setup
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.geometry(f"{self.settings.window_width}x{self.settings.window_height}")
        if self.settings.window_x is not None and self.settings.window_y is not None:
            self.geometry(f"+{self.settings.window_x}+{self.settings.window_y}")
        self.minsize(1200, 800)

        # Backend
        self.device = "cuda" if self._check_cuda() else "cpu"
        self.model_manager: Optional[ModelManager] = None
        self.pipeline: Optional[SynthIDPipeline] = None
        self.current_image_path: Optional[str] = None
        self.output_image_path: Optional[str] = None
        self.processing_thread: Optional[threading.Thread] = None

        self._build_ui()
        self._load_settings_to_ui()
        self._init_backend()
        self._bind_shortcuts()

        # Save window position on close
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _check_cuda(self) -> bool:
        try:
            import torch
            return torch.cuda.is_available()
        except:
            return False

    def _init_backend(self):
        try:
            self.model_manager = ModelManager(MODEL_PATHS, self.device)
            self.pipeline = SynthIDPipeline(self.model_manager, str(OUTPUT_DIR), self.device)

            missing = self.model_manager.missing_models
            if missing:
                self.status_label.configure(
                    text=f"⚠️ Missing {len(missing)} models. Run: python download_models.py",
                    text_color="orange"
                )
                self.process_btn.configure(state="disabled")
            else:
                self.status_label.configure(
                    text=f"✅ Ready | Device: {self.device.upper()}",
                    text_color="green"
                )
                self.process_btn.configure(state="normal")

            if hasattr(self, 'model_status'):
                self.model_status.model_manager = self.model_manager
                self.model_status._update_status()

        except Exception as e:
            self.status_label.configure(text=f"❌ Init error: {e}", text_color="red")
            logger.exception("Backend init failed")

    def _bind_shortcuts(self):
        """Bind keyboard shortcuts."""
        self.bind("<Control-o>", lambda e: self._load_image())
        self.bind("<Control-O>", lambda e: self._load_image())
        self.bind("<Control-s>", lambda e: self._open_output())
        self.bind("<Control-S>", lambda e: self._open_output())
        self.bind("<Control-r>", lambda e: self._start_processing())
        self.bind("<Control-R>", lambda e: self._start_processing())
        self.bind("<Escape>", lambda e: self._cancel_processing())
        self.bind("<Control-q>", lambda e: self._on_close())
        self.bind("<Control-Q>", lambda e: self._on_close())

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=0)

        # ===== HEADER =====
        self.header = ctk.CTkFrame(self, height=60)
        self.header.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
        self.header.grid_propagate(False)

        self.title_label = ctk.CTkLabel(
            self.header, text=f"🛡️ {APP_NAME}",
            font=ctk.CTkFont(size=24, weight="bold")
        )
        self.title_label.place(relx=0.02, rely=0.5, anchor="w")

        self.version_label = ctk.CTkLabel(
            self.header, text=f"v{APP_VERSION}",
            font=ctk.CTkFont(size=12), text_color="gray"
        )
        self.version_label.place(relx=0.98, rely=0.5, anchor="e")

        # ===== CONTENT =====
        self.content = ctk.CTkFrame(self)
        self.content.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        self.content.grid_columnconfigure(0, weight=2)
        self.content.grid_columnconfigure(1, weight=1)
        self.content.grid_rowconfigure(0, weight=1)

        # --- Left: Image Preview + Comparison ---
        self.left_panel = ctk.CTkFrame(self.content)
        self.left_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 5), pady=0)
        self.left_panel.grid_rowconfigure(0, weight=1)
        self.left_panel.grid_rowconfigure(1, weight=0)
        self.left_panel.grid_columnconfigure(0, weight=1)

        # Tabbed view
        self.view_tabs = ctk.CTkTabview(self.left_panel)
        self.view_tabs.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.view_tabs.add("Input")
        self.view_tabs.add("Before/After")

        # Input tab
        self.drag_drop = DragDropImage(
            self.view_tabs.tab("Input"),
            on_drop=self._on_image_dropped,
            fg_color="transparent"
        )
        self.drag_drop.pack(expand=True, fill="both", padx=5, pady=5)

        # Before/After tab
        self.comparison = BeforeAfterSlider(self.view_tabs.tab("Before/After"))
        self.comparison.pack(expand=True, fill="both", padx=5, pady=5)

        # Image buttons
        self.image_btn_frame = ctk.CTkFrame(self.left_panel)
        self.image_btn_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 10))

        self.load_btn = ctk.CTkButton(
            self.image_btn_frame, text="📁 Load (Ctrl+O)",
            command=self._load_image
        )
        self.load_btn.pack(side="left", padx=(0, 5))

        self.clear_btn = ctk.CTkButton(
            self.image_btn_frame, text="🗑️ Clear",
            command=self._clear_image, fg_color="gray"
        )
        self.clear_btn.pack(side="left", padx=5)

        self.output_btn = ctk.CTkButton(
            self.image_btn_frame, text="📂 Output (Ctrl+S)",
            command=self._open_output
        )
        self.output_btn.pack(side="right", padx=5)

        # --- Right: Controls ---
        self.controls = ctk.CTkScrollableFrame(self.content, width=380)
        self.controls.grid(row=0, column=1, sticky="nsew", padx=(5, 0), pady=0)

        # Model Status
        self.model_status = ModelStatusWidget(self.controls, self.model_manager if self.model_manager else None)
        self.model_status.pack(fill="x", padx=5, pady=(0, 10))

        # Prompts
        self._add_section_header(self.controls, "📝 Prompts")

        self.positive_prompt = ctk.CTkTextbox(self.controls, height=60)
        self.positive_prompt.pack(fill="x", padx=5, pady=(0, 5))

        self.negative_prompt = ctk.CTkTextbox(self.controls, height=60)
        self.negative_prompt.pack(fill="x", padx=5, pady=(0, 10))

        # Denoise
        self._add_section_header(self.controls, "🎚️ Denoise")

        self.denoise_auto = ctk.CTkSwitch(
            self.controls, text="Auto from resolution",
            onvalue=True, offvalue=False
        )
        self.denoise_auto.pack(fill="x", padx=5, pady=5)

        self.denoise_frame = ctk.CTkFrame(self.controls)
        self.denoise_frame.pack(fill="x", padx=5, pady=5)
        ctk.CTkLabel(self.denoise_frame, text="Manual:").pack(side="left", padx=5)
        self.denoise_slider = ctk.CTkSlider(
            self.denoise_frame, from_=0.0, to=1.0, number_of_steps=100
        )
        self.denoise_slider.set(DEFAULTS["denoise_manual"])
        self.denoise_slider.pack(side="left", fill="x", expand=True, padx=5)
        self.denoise_value = ctk.CTkLabel(self.denoise_frame, text="0.12", width=40)
        self.denoise_value.pack(side="right", padx=5)
        self.denoise_slider.configure(
            command=lambda v: self.denoise_value.configure(text=f"{float(v):.2f}")
        )

        # Face Enhancement
        self._add_section_header(self.controls, "😊 Face Enhancement")

        self.face_switch = ctk.CTkSwitch(
            self.controls, text="Enable face enhancement",
            onvalue=True, offvalue=False
        )
        self.face_switch.pack(fill="x", padx=5, pady=5)

        self.face_scale_frame = ctk.CTkFrame(self.controls)
        self.face_scale_frame.pack(fill="x", padx=5, pady=5)
        ctk.CTkLabel(self.face_scale_frame, text="Face scale:").pack(side="left", padx=5)
        self.face_scale = ctk.CTkSlider(
            self.face_scale_frame, from_=0.1, to=2.0, number_of_steps=19
        )
        self.face_scale.set(DEFAULTS["face_denoise_scale"])
        self.face_scale.pack(side="left", fill="x", expand=True, padx=5)
        self.face_scale_val = ctk.CTkLabel(self.face_scale_frame, text="0.7", width=40)
        self.face_scale_val.pack(side="right", padx=5)
        self.face_scale.configure(
            command=lambda v: self.face_scale_val.configure(text=f"{float(v):.2f}")
        )

        # Generation
        self._add_section_header(self.controls, "⚙️ Generation")

        self.steps_frame = ctk.CTkFrame(self.controls)
        self.steps_frame.pack(fill="x", padx=5, pady=5)
        ctk.CTkLabel(self.steps_frame, text="Steps:").pack(side="left", padx=5)
        self.steps_slider = ctk.CTkSlider(
            self.steps_frame, from_=1, to=50, number_of_steps=49
        )
        self.steps_slider.set(DEFAULTS["steps"])
        self.steps_slider.pack(side="left", fill="x", expand=True, padx=5)
        self.steps_val = ctk.CTkLabel(self.steps_frame, text="4", width=30)
        self.steps_val.pack(side="right", padx=5)
        self.steps_slider.configure(
            command=lambda v: self.steps_val.configure(text=f"{int(float(v))}")
        )

        self.seed_frame = ctk.CTkFrame(self.controls)
        self.seed_frame.pack(fill="x", padx=5, pady=5)
        ctk.CTkLabel(self.seed_frame, text="Seed:").pack(side="left", padx=5)
        self.seed_entry = ctk.CTkEntry(self.seed_frame, placeholder_text="-1 = random")
        self.seed_entry.insert(0, str(DEFAULTS["seed"]))
        self.seed_entry.pack(side="left", fill="x", expand=True, padx=5)

        # Output
        self._add_section_header(self.controls, "💾 Output")

        self.format_frame = ctk.CTkFrame(self.controls)
        self.format_frame.pack(fill="x", padx=5, pady=5)
        ctk.CTkLabel(self.format_frame, text="Format:").pack(side="left", padx=5)
        self.format_combo = ctk.CTkComboBox(
            self.format_frame, values=["png", "jpg", "webp"]
        )
        self.format_combo.set(DEFAULTS["output_format"])
        self.format_combo.pack(side="left", fill="x", expand=True, padx=5)

        self.quality_frame = ctk.CTkFrame(self.controls)
        self.quality_frame.pack(fill="x", padx=5, pady=5)
        ctk.CTkLabel(self.quality_frame, text="Quality:").pack(side="left", padx=5)
        self.quality_slider = ctk.CTkSlider(
            self.quality_frame, from_=1, to=100, number_of_steps=99
        )
        self.quality_slider.set(DEFAULTS["output_quality"])
        self.quality_slider.pack(side="left", fill="x", expand=True, padx=5)
        self.quality_val = ctk.CTkLabel(self.quality_frame, text="95", width=30)
        self.quality_val.pack(side="right", padx=5)
        self.quality_slider.configure(
            command=lambda v: self.quality_val.configure(text=f"{int(float(v))}")
        )

        # Progress Card
        self._add_section_header(self.controls, "📊 Progress")
        self.progress_card = ProgressCard(self.controls, total_stages=12)
        self.progress_card.pack(fill="x", padx=5, pady=5)

        # Actions
        self._add_section_header(self.controls, "▶️ Actions")

        self.process_btn = ctk.CTkButton(
            self.controls, text="🚀 Remove SynthID (Ctrl+R)",
            command=self._start_processing,
            height=45,
            font=ctk.CTkFont(size=16, weight="bold")
        )
        self.process_btn.pack(fill="x", padx=5, pady=10)

        self.cancel_btn = ctk.CTkButton(
            self.controls, text="⏹️ Cancel (Esc)",
            command=self._cancel_processing,
            height=35, fg_color="darkred",
            hover_color="red"
        )
        self.cancel_btn.pack(fill="x", padx=5, pady=5)
        self.cancel_btn.configure(state="disabled")

        # Overall progress bar
        self.progress = ctk.CTkProgressBar(self.controls)
        self.progress.set(0)
        self.progress.pack(fill="x", padx=5, pady=(10, 5))

        self.progress_label = ctk.CTkLabel(
            self.controls, text="Ready",
            font=ctk.CTkFont(size=12)
        )
        self.progress_label.pack(fill="x", padx=5, pady=(0, 10))

        # ===== STATUS BAR =====
        self.status_frame = ctk.CTkFrame(self, height=30)
        self.status_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=(5, 10))
        self.status_frame.grid_propagate(False)

        self.status_label = ctk.CTkLabel(
            self.status_frame, text="Initializing...",
            font=ctk.CTkFont(size=12)
        )
        self.status_label.place(relx=0.01, rely=0.5, anchor="w")

        self.device_label = ctk.CTkLabel(
            self.status_frame,
            text=f"Device: {self.device.upper()}",
            font=ctk.CTkFont(size=11), text_color="gray"
        )
        self.device_label.place(relx=0.99, rely=0.5, anchor="e")

    def _add_section_header(self, parent, text: str):
        label = ctk.CTkLabel(
            parent, text=text,
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color="lightblue"
        )
        label.pack(fill="x", padx=5, pady=(15, 5))
        ctk.CTkFrame(parent, height=2, fg_color="gray").pack(fill="x", padx=5, pady=(0, 5))

    def _load_settings_to_ui(self):
        """Load saved settings into UI controls."""
        s = self.settings
        self.positive_prompt.insert("0.0", s.last_positive_prompt)
        self.negative_prompt.insert("0.0", s.last_negative_prompt)

        if s.default_denoise_auto:
            self.denoise_auto.select()
        else:
            self.denoise_auto.deselect()

        self.denoise_slider.set(s.default_denoise_manual)
        self.denoise_value.configure(text=f"{s.default_denoise_manual:.2f}")

        if s.default_face_enhancement:
            self.face_switch.select()
        else:
            self.face_switch.deselect()

        self.face_scale.set(s.default_face_denoise_scale)
        self.face_scale_val.configure(text=f"{s.default_face_denoise_scale:.2f}")

        self.steps_slider.set(s.default_steps)
        self.steps_val.configure(text=str(s.default_steps))

        self.format_combo.set(s.default_output_format)
        self.quality_slider.set(s.default_output_quality)
        self.quality_val.configure(text=str(s.default_output_quality))

    def _save_settings_from_ui(self):
        """Save current UI state to settings."""
        self.settings_manager.update(
            window_width=self.winfo_width(),
            window_height=self.winfo_height(),
            window_x=self.winfo_x(),
            window_y=self.winfo_y(),
            last_positive_prompt=self.positive_prompt.get("0.0", "end").strip(),
            last_negative_prompt=self.negative_prompt.get("0.0", "end").strip(),
            default_denoise_auto=bool(self.denoise_auto.get()),
            default_denoise_manual=float(self.denoise_slider.get()),
            default_face_enhancement=bool(self.face_switch.get()),
            default_face_denoise_scale=float(self.face_scale.get()),
            default_steps=int(self.steps_slider.get()),
            default_output_format=self.format_combo.get(),
            default_output_quality=int(self.quality_slider.get()),
        )

    def _on_close(self):
        """Save settings and close application."""
        self._save_settings_from_ui()
        self.destroy()

    def _on_image_dropped(self, path: str):
        self.current_image_path = path
        self.drag_drop.set_image(path)
        self.status_label.configure(text=f"📷 Loaded: {Path(path).name}")
        self.view_tabs.set("Input")

    def _load_image(self):
        from tkinter import filedialog

        initial_dir = self.settings.last_input_dir or str(INPUT_DIR)
        path = filedialog.askopenfilename(
            title="Select Image",
            initialdir=initial_dir,
            filetypes=[
                ("Images", "*.png *.jpg *.jpeg *.webp *.bmp"),
                ("All files", "*.*")
            ]
        )
        if path:
            self.settings_manager.update(last_input_dir=str(Path(path).parent))
            self._on_image_dropped(path)

    def _clear_image(self):
        self.current_image_path = None
        self.output_image_path = None
        self.drag_drop.clear()
        self.progress_card.reset()
        self.progress.set(0)
        self.progress_label.configure(text="Ready")
        self.status_label.configure(text="Image cleared")

    def _open_output(self):
        import subprocess
        path = str(OUTPUT_DIR)
        if sys.platform == "win32":
            os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.run(["open", path])
        else:
            subprocess.run(["xdg-open", path])

    def _start_processing(self):
        if not self.current_image_path:
            self.status_label.configure(text="❌ No image loaded!", text_color="red")
            return

        if not self.pipeline:
            self.status_label.configure(text="❌ Pipeline not ready!", text_color="red")
            return

        try:
            seed_val = int(self.seed_entry.get())
        except:
            seed_val = -1

        config = PipelineConfig(
            image_path=self.current_image_path,
            positive_prompt=self.positive_prompt.get("0.0", "end"),
            negative_prompt=self.negative_prompt.get("0.0", "end"),
            denoise_auto=bool(self.denoise_auto.get()),
            denoise_manual=float(self.denoise_slider.get()),
            denoise_scale=1.0,
            face_enhancement=bool(self.face_switch.get()),
            face_denoise_scale=float(self.face_scale.get()),
            steps=int(self.steps_slider.get()),
            seed=seed_val,
            output_format=self.format_combo.get(),
            output_quality=int(self.quality_slider.get()),
        )

        self.process_btn.configure(state="disabled")
        self.cancel_btn.configure(state="normal")
        self.progress.set(0)
        self.progress_card.reset()

        self.processing_thread = threading.Thread(target=self._run_pipeline, args=(config,))
        self.processing_thread.daemon = True
        self.processing_thread.start()

    def _run_pipeline(self, config: PipelineConfig):
        def progress_callback(current, total, message):
            self.after(0, lambda: self._update_progress(current, total, message))

        result = self.pipeline.run(config, progress_callback)
        self.after(0, lambda: self._processing_complete(result))

    def _update_progress(self, current: int, total: int, message: str):
        if total > 0:
            progress = current / total
            self.progress.set(progress)
            self.progress_label.configure(text=f"Stage {current}/{total}: {message}")
            self.status_label.configure(text=f"Processing... {current}/{total}")
            self.progress_card.update_stage(current, message, done=current < total)
            if current > 1:
                self.progress_card.update_stage(current - 1, "", done=True)

    def _processing_complete(self, result: PipelineResult):
        self.process_btn.configure(state="normal")
        self.cancel_btn.configure(state="disabled")
        self.progress.set(1.0 if result.success else 0.0)

        if result.success:
            self.progress_label.configure(text=f"✅ Done in {result.processing_time:.1f}s")
            self.status_label.configure(
                text=f"✅ Saved: {Path(result.output_path).name}",
                text_color="green"
            )

            if result.output_path and Path(result.output_path).exists():
                self.output_image_path = result.output_path
                if self.settings.show_comparison_on_complete:
                    try:
                        self.comparison.set_images(self.current_image_path, result.output_path)
                        self.view_tabs.set("Before/After")
                    except Exception as e:
                        logger.warning(f"Comparison view failed: {e}")
        else:
            self.progress_label.configure(text=f"❌ Failed: {result.error_message}")
            self.status_label.configure(text="Processing failed", text_color="red")

    def _cancel_processing(self):
        if self.pipeline:
            self.pipeline.cancel()
        self.status_label.configure(text="Cancelling...", text_color="orange")
        self.cancel_btn.configure(state="disabled")


def main():
    app = SynthIDRemoverApp()
    app.mainloop()


if __name__ == "__main__":
    main()
