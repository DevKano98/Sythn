# 🛡️ SynthID Remover v2.0 — Standalone Desktop App

A fully self-contained desktop application for removing Google SynthID watermarks from AI-generated images. **No ComfyUI required** — everything runs inside the app.

![App Screenshot](assets/screenshot.png)

---

## Features

- **Standalone Operation** — Complete integrated pipeline, no external dependencies
- **Adaptive Denoise** — Auto-calculates optimal strength from image resolution
- **ControlNet Guidance** — Preserves image structure during reconstruction
- **Face Detection & Enhancement** — YOLOv8 + per-face reconstruction with seamless compositing
- **GGUF Model Support** — Efficient quantized model inference
- **Modern GUI** — CustomTkinter with dark theme, drag-and-drop, before/after slider
- **Batch Processing** — Headless CLI mode for folders
- **Cross-Platform** — Windows, macOS, Linux

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Download models (~15 GB)
python download_models.py

# 3. Launch GUI
python main.py

# 4. Or process a folder headless
python main.py --headless --input ./photos/ --output ./results/
```

---

## Requirements

- **Python**: 3.10+
- **GPU**: NVIDIA CUDA (recommended) or CPU
- **RAM**: 16 GB+ (8 GB minimum for CPU)
- **Disk**: ~20 GB for models

---

## Installation

### Step 1: Clone/Extract

```bash
cd synthid-remover-app
```

### Step 2: Virtual Environment

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate
```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 4: Download Models

```bash
# Automatic download (requires huggingface-hub)
python download_models.py

# Check what you have
python download_models.py --check

# Force re-download
python download_models.py --force
```

**Models needed** (~15 GB total):

| Model | File | Size | Source |
|-------|------|------|--------|
| Main Reconstruction | `qwen-image-2512-Q4_K_M.gguf` | ~4.5 GB | HuggingFace |
| VAE | `qwen_image_vae.safetensors` | ~300 MB | HuggingFace |
| ControlNet | `qwen_image_canny_diffsynth_controlnet.safetensors` | ~1.2 GB | HuggingFace |
| Prompt Encoder | `Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf` | ~4.5 GB | HuggingFace |
| Lightning LoRA | `Qwen-Image-2512-Lightning-4steps-V1.0.safetensors` | ~150 MB | HuggingFace |
| Face Detection | `yolov8n-face.pt` | ~6 MB | GitHub |
| Face Reconstruction | `z_image_turbo-Q4_K_M.gguf` | ~2.5 GB | HuggingFace |
| Face Encoder | `Qwen_3_4b-imatrix-IQ4_XS.gguf` | ~1.8 GB | HuggingFace |
| Face VAE | `ae.safetensors` | ~80 MB | HuggingFace |

---

## Usage

### GUI Mode

```bash
python main.py
```

1. **Load Image** — Click "Load" or drag-and-drop (Ctrl+O)
2. **Configure** — Adjust prompts, denoise, face enhancement
3. **Process** — Click "🚀 Remove SynthID" (Ctrl+R)
4. **Review** — Use Before/After slider to compare
5. **Output** — Saved automatically to `output/`

### Headless / Batch Mode

```bash
# Single image
python main.py --headless --input image.png

# Entire folder
python main.py --headless --input ./photos/ --output ./results/

# Check system and models
python main.py --check
```

### Building Executable

```bash
pip install pyinstaller
python build.py
```

Output: `dist/SynthID-Remover/`

---

## Architecture

12-stage processing pipeline:

```
Input Image
  ↓
1. Load & Normalize
2. Adaptive Denoise (resolution-aware)
3. Canny Edge Extraction
4. ControlNet Conditioning
5. Prompt Encoding (Qwen2.5-VL)
6. VAE Latent Encoding
7. Main Reconstruction (Qwen Image 2512)
8. Face Detection (YOLOv8)
9. Face Segmentation
10. Face Reconstruction (z_image_turbo)
11. Compositing (feathered merge)
12. Export (PNG/JPG/WebP)
```

See [docs/architecture.md](docs/architecture.md) for full details.

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+O | Load image |
| Ctrl+S | Open output folder |
| Ctrl+R | Start processing |
| Escape | Cancel processing |
| Ctrl+Q | Quit |

---

## Project Structure

```
synthid-remover-app/
├── main.py                  # Entry point (GUI + CLI)
├── config.py                # App config & model paths
├── requirements.txt         # Dependencies
├── download_models.py       # Model downloader
├── build.py                 # PyInstaller build script
├── models/                  # Downloaded models (not included)
├── input/                   # Default input folder
├── output/                  # Default output folder
├── src/
│   ├── models/              # Model loading & inference
│   ├── pipeline/            # 12-stage pipeline
│   ├── gui/                 # CustomTkinter UI
│   └── utils/               # Image processing, helpers
├── tests/                   # Unit tests
└── docs/                    # Documentation
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Missing models" | Run `python download_models.py` |
| Out of memory | Use smaller images, CPU mode, or close apps |
| Slow processing | Ensure GPU is active (check status bar) |
| Face detection fails | Verify `yolov8n-face.pt` in `models/` |
| GUI won't start | Python 3.10+ required. Run `pip install -r requirements.txt` |
| Build fails | Try `python build.py --onedir` instead of `--onefile` |

See [docs/faq.md](docs/faq.md) for more.

---

## Performance

| Mode | Time per Image |
|------|---------------|
| GPU + Lightning (4 steps) | 5-15 seconds |
| GPU + Standard (20 steps) | 30-60 seconds |
| CPU + Lightning | 2-5 minutes |
| CPU + Standard | 10-20 minutes |

---

## Documentation

- [Usage Guide](docs/usage.md)
- [Architecture](docs/architecture.md)
- [Model Reference](docs/models.md)
- [FAQ](docs/faq.md)
- [Contributing](CONTRIBUTING.md)

---

## License

MIT License — See [LICENSE](LICENSE)

Use for legitimate content ownership and research purposes only.

---

## Credits

- Qwen models by Alibaba Cloud
- YOLOv8 by Ultralytics
- CustomTkinter by Tom Schimansky
