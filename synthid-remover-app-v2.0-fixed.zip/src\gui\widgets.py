"""Custom GUI widgets for SynthID Remover"""
import tkinter as tk
import customtkinter as ctk
from PIL import Image, ImageTk
from typing import Callable, Optional, Tuple


class DragDropImage(ctk.CTkFrame):
    """Image display area with drag-and-drop support."""

    def __init__(self, master, on_drop: Callable[[str], None], **kwargs):
        super().__init__(master, **kwargs)
        self.on_drop = on_drop
        self.image_path: Optional[str] = None
        self.photo_image: Optional[ImageTk.PhotoImage] = None

        self.label = ctk.CTkLabel(self, text="Drop image here\nor click to browse",
                                  font=ctk.CTkFont(size=14))
        self.label.pack(expand=True, fill="both", padx=10, pady=10)

        # Bind drag events (platform-specific)
        self.label.bind("<Button-1>", self._on_click)
        self._setup_drag_drop()

    def _setup_drag_drop(self):
        """Setup drag and drop handlers."""
        try:
            from tkinterdnd2 import DND_FILES

            self.label.drop_target_register(DND_FILES)
            self.label.dnd_bind("<<Drop>>", self._on_drop)
        except (ImportError, AttributeError, tk.TclError):
            # Drag-drop not available, fallback to click
            pass

    def _on_click(self, event):
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp"), ("All", "*.*")]
        )
        if path:
            self.set_image(path)
            self.on_drop(path)

    def _on_drop(self, event):
        path = event.data.strip("{}")
        if path:
            self.set_image(path)
            self.on_drop(path)

    def set_image(self, path: str, max_size: Tuple[int, int] = (500, 500)):
        """Display image from path."""
        try:
            img = Image.open(path)
            img.thumbnail(max_size, Image.LANCZOS)
            self.photo_image = ImageTk.PhotoImage(img)
            self.label.configure(image=self.photo_image, text="")
            self.image_path = path
        except Exception as e:
            self.label.configure(text=f"Error: {e}", image=None)

    def clear(self):
        self.label.configure(image=None, text="Drop image here\nor click to browse")
        self.image_path = None
        self.photo_image = None


class BeforeAfterSlider(ctk.CTkFrame):
    """Before/After comparison slider widget."""

    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.before_img: Optional[ImageTk.PhotoImage] = None
        self.after_img: Optional[ImageTk.PhotoImage] = None
        self._before_pil: Optional[Image.Image] = None
        self._after_pil: Optional[Image.Image] = None
        self.slider_value = 0.5

        self.canvas = tk.Canvas(self, bg="black", highlightthickness=0)
        self.canvas.pack(expand=True, fill="both")

        self.slider = ctk.CTkSlider(self, from_=0, to=1, number_of_steps=100)
        self.slider.set(0.5)
        self.slider.pack(fill="x", padx=5, pady=5)
        self.slider.configure(command=self._on_slider)

        self.canvas.bind("<Configure>", self._on_resize)

    def set_images(self, before_path: str, after_path: str):
        """Load before and after images."""
        self._before_pil = Image.open(before_path).convert("RGB")
        self._after_pil = Image.open(after_path).convert("RGB")
        self._draw()

    def _on_slider(self, value):
        self.slider_value = float(value)
        self._draw()

    def _on_resize(self, event):
        self._draw()

    def _draw(self):
        if self._before_pil is None or self._after_pil is None:
            return

        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        if w <= 1 or h <= 1:
            return

        before = self._fit_to_canvas(self._before_pil, w, h)
        after = self._fit_to_canvas(self._after_pil, w, h).resize(before.size, Image.LANCZOS)
        image_w, image_h = before.size
        split = int(w * self.slider_value)
        image_x = (w - image_w) // 2
        image_y = (h - image_h) // 2
        local_split = max(0, min(image_w, split - image_x))

        composite = before.copy()
        if local_split < image_w:
            right = after.crop((local_split, 0, image_w, image_h))
            composite.paste(right, (local_split, 0))

        self.before_img = ImageTk.PhotoImage(composite)

        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor="nw", image=self.before_img)
        self.canvas.move("all", image_x, image_y)
        self.canvas.create_line(split, image_y, split, image_y + image_h, fill="white", width=2)

    @staticmethod
    def _fit_to_canvas(image: Image.Image, width: int, height: int) -> Image.Image:
        fitted = image.copy()
        fitted.thumbnail((width, height), Image.LANCZOS)
        return fitted


class ModelStatusWidget(ctk.CTkFrame):
    """Display model availability status."""

    def __init__(self, master, model_manager, **kwargs):
        super().__init__(master, **kwargs)
        self.model_manager = model_manager

        self.title = ctk.CTkLabel(self, text="📦 Model Status",
                                  font=ctk.CTkFont(size=14, weight="bold"))
        self.title.pack(anchor="w", padx=5, pady=5)

        self.status_frame = ctk.CTkFrame(self)
        self.status_frame.pack(fill="x", padx=5, pady=5)

        self._update_status()

    def _update_status(self):
        for widget in self.status_frame.winfo_children():
            widget.destroy()

        if self.model_manager is None:
            lbl = ctk.CTkLabel(
                self.status_frame, text="Model manager not initialized",
                text_color="orange", font=ctk.CTkFont(size=11)
            )
            lbl.pack(anchor="w", padx=5)
            return

        for name, path in self.model_manager.model_paths.items():
            exists = path.exists()
            color = "green" if exists else "red"
            text = "✅" if exists else "❌"
            lbl = ctk.CTkLabel(self.status_frame, text=f"{text} {name}",
                                text_color=color, font=ctk.CTkFont(size=11))
            lbl.pack(anchor="w", padx=5)


class ProgressCard(ctk.CTkFrame):
    """Stage-by-stage progress display."""

    def __init__(self, master, total_stages: int = 12, **kwargs):
        super().__init__(master, **kwargs)
        self.total_stages = total_stages
        self.stage_labels: list = []

        self.title = ctk.CTkLabel(self, text="📊 Pipeline Progress",
                                  font=ctk.CTkFont(size=14, weight="bold"))
        self.title.pack(anchor="w", padx=5, pady=5)

        for i in range(1, total_stages + 1):
            lbl = ctk.CTkLabel(self, text=f"  ⏳ Stage {i}",
                              font=ctk.CTkFont(size=11), text_color="gray")
            lbl.pack(anchor="w", padx=5, pady=1)
            self.stage_labels.append(lbl)

    def update_stage(self, stage_num: int, status: str, done: bool = False):
        """Update a stage's status."""
        if 1 <= stage_num <= self.total_stages:
            idx = stage_num - 1
            symbol = "✅" if done else "▶️"
            color = "green" if done else "yellow"
            self.stage_labels[idx].configure(
                text=f"  {symbol} Stage {stage_num}: {status}",
                text_color=color
            )

    def reset(self):
        for i, lbl in enumerate(self.stage_labels, 1):
            lbl.configure(text=f"  ⏳ Stage {i}", text_color="gray")
