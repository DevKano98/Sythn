#!/usr/bin/env python3
"""Download all required models for SynthID Remover

Usage:
    python download_models.py              # Download all missing models
    python download_models.py --check     # Check only, don't download
    python download_models.py --force     # Re-download all models

Models are saved to the models/ directory.
"""
import os
import sys
import argparse
import hashlib
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass


@dataclass
class ModelInfo:
    name: str
    filename: str
    repo_id: str
    file_path: str  # Path within the repo
    size_gb: float
    description: str
    required: bool = True


MODELS: List[ModelInfo] = [
    ModelInfo(
        name="reconstruction",
        filename="qwen-image-2512-Q4_K_M.gguf",
        repo_id="Qwen/Qwen2.5-VL-7B-Instruct-GGUF",
        file_path="qwen2.5-vl-7b-instruct-q4_k_m.gguf",
        size_gb=4.5,
        description="Main image reconstruction (Qwen Image 2512)",
    ),
    ModelInfo(
        name="prompt_encoder",
        filename="Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf",
        repo_id="Qwen/Qwen2.5-VL-7B-Instruct-GGUF",
        file_path="qwen2.5-vl-7b-instruct-q4_k_m.gguf",
        size_gb=4.5,
        description="Vision-language prompt encoder",
    ),
    ModelInfo(
        name="vae",
        filename="qwen_image_vae.safetensors",
        repo_id="Qwen/Qwen2.5-VL",
        file_path="vae/diffusion_pytorch_model.safetensors",
        size_gb=0.3,
        description="VAE for latent encoding/decoding",
    ),
    ModelInfo(
        name="controlnet",
        filename="qwen_image_canny_diffsynth_controlnet.safetensors",
        repo_id="Qwen/Qwen2.5-VL",
        file_path="controlnet/diffusion_pytorch_model.safetensors",
        size_gb=1.2,
        description="Canny ControlNet for structure preservation",
    ),
    ModelInfo(
        name="lightning_lora",
        filename="Qwen-Image-2512-Lightning-4steps-V1.0.safetensors",
        repo_id="Qwen/Qwen-Image-Lightning",
        file_path="pytorch_lora_weights.safetensors",
        size_gb=0.15,
        description="Lightning LoRA for 4-step generation",
    ),
    ModelInfo(
        name="face_detection",
        filename="yolov8n-face.pt",
        repo_id="",
        file_path="",
        size_gb=0.006,
        description="YOLOv8 face detection",
    ),
    ModelInfo(
        name="face_reconstruction",
        filename="z_image_turbo-Q4_K_M.gguf",
        repo_id="stabilityai/stable-diffusion-xl-base-1.0",
        file_path="unet/diffusion_pytorch_model.fp16.safetensors",
        size_gb=2.5,
        description="Face-specific reconstruction model",
    ),
    ModelInfo(
        name="face_encoder",
        filename="Qwen_3_4b-imatrix-IQ4_XS.gguf",
        repo_id="Qwen/Qwen2.5-3B-Instruct-GGUF",
        file_path="qwen2.5-3b-instruct-iq4_xs.gguf",
        size_gb=1.8,
        description="Face prompt encoder",
    ),
    ModelInfo(
        name="face_vae",
        filename="ae.safetensors",
        repo_id="stabilityai/stable-diffusion-xl-base-1.0",
        file_path="vae/diffusion_pytorch_model.fp16.safetensors",
        size_gb=0.08,
        description="Face VAE",
    ),
]


def check_hf_cli() -> bool:
    """Check if huggingface-cli is available."""
    try:
        import huggingface_hub
        return True
    except ImportError:
        return False


def download_hf(model: ModelInfo, models_dir: Path, force: bool = False) -> bool:
    """Download a model from HuggingFace."""
    dest = models_dir / model.filename

    if dest.exists() and not force:
        print(f"  ✅ {model.name} already exists ({dest.stat().st_size / 1e9:.2f} GB)")
        return True

    if not model.repo_id:
        print(f"  ⚠️ {model.name}: No HuggingFace repo configured. Manual download required.")
        print(f"     Save as: {dest}")
        return False

    try:
        from huggingface_hub import hf_hub_download

        print(f"  ⬇️  Downloading {model.name} from {model.repo_id}...")
        print(f"     File: {model.file_path}")
        print(f"     Expected size: ~{model.size_gb} GB")
        print(f"     This may take several minutes...")

        downloaded = hf_hub_download(
            repo_id=model.repo_id,
            filename=model.file_path,
            local_dir=str(models_dir),
            local_dir_use_symlinks=False,
        )

        # Rename to expected filename if different
        downloaded_path = Path(downloaded)
        if downloaded_path.name != model.filename:
            final_path = models_dir / model.filename
            if final_path.exists():
                final_path.unlink()
            downloaded_path.rename(final_path)
            print(f"     Renamed to {model.filename}")

        actual_size = dest.stat().st_size / 1e9
        print(f"  ✅ {model.name} downloaded ({actual_size:.2f} GB)")
        return True

    except Exception as e:
        print(f"  ❌ Failed to download {model.name}: {e}")
        return False


def download_yolo(models_dir: Path) -> bool:
    """Download YOLOv8 face detection model using ultralytics."""
    dest = models_dir / "yolov8n-face.pt"

    if dest.exists():
        print(f"  ✅ face_detection already exists")
        return True

    try:
        print(f"  ⬇️  Downloading yolov8n-face.pt...")
        import urllib.request
        url = "https://github.com/akanametov/yolov8-face/releases/download/v0.0.1/yolov8n-face.pt"
        urllib.request.urlretrieve(url, str(dest))
        print(f"  ✅ face_detection downloaded ({dest.stat().st_size / 1e6:.1f} MB)")
        return True
    except Exception as e:
        print(f"  ❌ Failed to download yolov8n-face.pt: {e}")
        print(f"     Manual download: https://github.com/akanametov/yolov8-face")
        return False


def check_models(models_dir: Path) -> Tuple[List[ModelInfo], List[ModelInfo]]:
    """Check which models are present. Returns (present, missing)."""
    present = []
    missing = []

    print("\nModel Status:")
    print("-" * 70)

    for model in MODELS:
        dest = models_dir / model.filename
        if dest.exists():
            actual_size = dest.stat().st_size / 1e9
            status = "✅"
            present.append(model)
        else:
            actual_size = 0
            status = "❌"
            missing.append(model)

        size_str = f"({actual_size:.2f} GB)" if actual_size > 0 else f"(~{model.size_gb} GB)"
        print(f"  {status} {model.name:20s} {model.filename:45s} {size_str:12s} {model.description}")

    print("-" * 70)
    return present, missing


def main():
    parser = argparse.ArgumentParser(description="SynthID Remover Model Downloader")
    parser.add_argument("--check", action="store_true", help="Check only, don't download")
    parser.add_argument("--force", action="store_true", help="Re-download all models")
    parser.add_argument("--dir", type=str, default="models", help="Models directory")
    args = parser.parse_args()

    models_dir = Path(args.dir)
    models_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("SynthID Remover - Model Manager")
    print("=" * 70)
    print(f"Models directory: {models_dir.absolute()}")
    print()

    # Check HF CLI
    if not check_hf_cli():
        print("⚠️  huggingface_hub not installed. Install with:")
        print("   pip install huggingface-hub")
        print()
        print("You can also manually download models from:")
        for model in MODELS:
            if model.repo_id:
                print(f"   {model.repo_id}/{model.file_path}")
        print()

    # Check current status
    present, missing = check_models(models_dir)

    if args.check:
        print()
        if missing:
            print(f"Missing {len(missing)} model(s).")
            sys.exit(1)
        else:
            print("All models present! Ready to run.")
            sys.exit(0)

    if not missing and not args.force:
        print()
        print("All models already present. Use --force to re-download.")
        return

    if args.force:
        missing = MODELS  # Re-download all

    print()
    print(f"Downloading {len(missing)} model(s)...")
    print("⚠️  Note: These are large files. Total download: ~{:.1f} GB".format(
        sum(m.size_gb for m in missing)
    ))
    print()

    success_count = 0
    fail_count = 0

    for model in missing:
        if model.name == "face_detection":
            success = download_yolo(models_dir)
        else:
            success = download_hf(model, models_dir, args.force)

        if success:
            success_count += 1
        else:
            fail_count += 1
        print()

    print("=" * 70)
    print("Download Summary")
    print("=" * 70)
    print(f"Successful: {success_count}/{len(missing)}")
    print(f"Failed: {fail_count}/{len(missing)}")

    if fail_count > 0:
        print()
        print("For failed models, download manually from:")
        for model in missing:
            if not (models_dir / model.filename).exists():
                if model.repo_id:
                    print(f"  {model.name}: https://huggingface.co/{model.repo_id}")
                else:
                    print(f"  {model.name}: See docs/models.md")
        sys.exit(1)
    else:
        print()
        print("✅ All models downloaded successfully!")
        print("Run: python main.py")


if __name__ == "__main__":
    main()
