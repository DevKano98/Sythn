#!/usr/bin/env python3
"""SynthID Remover - Standalone Desktop Application

Usage:
    python main.py                    # Launch GUI
    python main.py --dev              # Dev mode with extra logging
    python main.py --headless         # Headless batch mode
    python main.py --input <path>     # Process single image or folder
    python main.py --output <dir>     # Output directory (headless)
    python main.py --check            # Check system and models
"""
import sys
import argparse
import logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import APP_NAME, APP_VERSION, MODEL_PATHS, DEVICE, OUTPUT_DIR
from src.utils.helpers import setup_logging, get_system_info
from src.utils.validators import validate_model_paths


def main():
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{APP_VERSION}")
    parser.add_argument("--dev", action="store_true", help="Development mode with debug logging")
    parser.add_argument("--headless", action="store_true", help="Run without GUI")
    parser.add_argument("--input", type=str, help="Input image or folder (headless)")
    parser.add_argument("--output", type=str, help="Output folder (headless)")
    parser.add_argument("--check", action="store_true", help="Check system and exit")
    parser.add_argument("--batch", action="store_true", help="Process folder in batch mode")
    args = parser.parse_args()

    setup_logging(level=logging.DEBUG if args.dev else logging.INFO)
    logger = logging.getLogger(__name__)

    logger.info(f"Starting {APP_NAME} v{APP_VERSION}")

    if args.check:
        print("=" * 60)
        print(f"{APP_NAME} v{APP_VERSION} - System Check")
        print("=" * 60)

        info = get_system_info()
        print(f"Platform: {info['platform']}")
        print(f"Python: {info['python_version'].split()[0]}")
        print(f"CPU cores: {info['cpu_count']}")
        print(f"RAM: {info['ram_gb']} GB total, {info['ram_available_gb']} GB available")
        print(f"CUDA: {'Yes' if info.get('cuda_available') else 'No'}")
        if info.get('cuda_available'):
            print(f"  CUDA version: {info.get('cuda_version')}")
            print(f"  GPUs: {info.get('gpu_count')}")
            for i, name in enumerate(info.get('gpu_names', [])):
                mem = info.get('gpu_memory_gb', [])[i] if i < len(info.get('gpu_memory_gb', [])) else "?"
                print(f"    [{i}] {name} ({mem} GB)")

        print()
        print("Model Status:")
        present, missing = validate_model_paths(MODEL_PATHS)
        for name in present:
            path = MODEL_PATHS[name]
            size = path.stat().st_size / 1e9
            print(f"  ✅ {name:20s} {path.name:45s} ({size:.2f} GB)")
        for name in missing:
            print(f"  ❌ {name:20s} NOT FOUND")

        print()
        if missing:
            print(f"Missing {len(missing)} model(s). Run: python download_models.py")
            sys.exit(1)
        else:
            print("All systems ready!")
            sys.exit(0)

    if args.headless or args.batch or args.input:
        from src.models.loader import ModelManager
        from src.pipeline.core import SynthIDPipeline, PipelineConfig
        from src.pipeline.batch import BatchProcessor
        from src.utils.validators import validate_image_path, validate_output_dir
        import os

        logger.info("Running in headless mode")

        model_manager = ModelManager(MODEL_PATHS, DEVICE)
        output_dir = args.output or str(OUTPUT_DIR)
        os.makedirs(output_dir, exist_ok=True)
        pipeline = SynthIDPipeline(model_manager, output_dir, DEVICE)

        input_path = args.input
        if not input_path:
            logger.error("No input specified. Use --input")
            sys.exit(1)

        input_path = Path(input_path)

        if input_path.is_file():
            try:
                validate_image_path(str(input_path))
                config = PipelineConfig(image_path=str(input_path))
                logger.info(f"Processing: {input_path}")
                result = pipeline.run(config)

                if result.success:
                    logger.info(f"✅ Success: {result.output_path} ({result.processing_time:.1f}s)")
                else:
                    logger.error(f"❌ Failed: {result.error_message}")
                    sys.exit(1)
            except Exception as e:
                logger.error(f"Error: {e}")
                sys.exit(1)

        elif input_path.is_dir():
            batch = BatchProcessor(pipeline, output_dir)

            def progress(current, total, stage, stage_total, filename, msg):
                pct = (current / total) * 100
                print(f"[{pct:.0f}%] ({current+1}/{total}) {filename}: {msg}")

            result = batch.process_folder(str(input_path), progress_callback=progress)

            print()
            print("=" * 60)
            print("Batch Processing Complete")
            print("=" * 60)
            print(f"Total: {result.total}")
            print(f"Successful: {result.successful}")
            print(f"Failed: {result.failed}")
            print(f"Time: {result.total_time:.1f}s")
            if result.errors:
                print(f"Errors: {len(result.errors)}")
                for err in result.errors[:5]:
                    print(f"  - {err}")
        else:
            logger.error(f"Invalid input: {input_path}")
            sys.exit(1)
    else:
        # Launch GUI
        from src.gui.app import main as gui_main
        gui_main()


if __name__ == "__main__":
    main()
