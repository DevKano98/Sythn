"""Tests for SynthID Remover"""
