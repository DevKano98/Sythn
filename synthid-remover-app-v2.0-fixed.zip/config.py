"""Configuration for SynthID Remover"""
from pathlib import Path

APP_NAME = "SynthID Remover"
APP_VERSION = "2.0.0"

# Paths
BASE_DIR = Path(__file__).parent
MODELS_DIR = BASE_DIR / "models"
INPUT_DIR = BASE_DIR / "input"
OUTPUT_DIR = BASE_DIR / "output"
TEMP_DIR = BASE_DIR / "temp"

# Ensure directories exist
for d in [MODELS_DIR, INPUT_DIR, OUTPUT_DIR, TEMP_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# Model filenames (place your downloaded models here)
MODELS = {
    "reconstruction": "qwen-image-2512-Q4_K_M.gguf",
    "vae": "qwen_image_vae.safetensors",
    "controlnet": "qwen_image_canny_diffsynth_controlnet.safetensors",
    "prompt_encoder": "Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf",
    "lightning_lora": "Qwen-Image-2512-Lightning-4steps-V1.0.safetensors",
    "face_detection": "yolov8n-face.pt",
    "face_reconstruction": "z_image_turbo-Q4_K_M.gguf",
    "face_encoder": "Qwen_3_4b-imatrix-IQ4_XS.gguf",
    "face_vae": "ae.safetensors",
}

# Model paths (resolved)
MODEL_PATHS = {k: MODELS_DIR / v for k, v in MODELS.items()}

# Processing defaults
DEFAULTS = {
    "positive_prompt": "high quality photo, detailed, sharp focus",
    "negative_prompt": "watermark, synthid, text, logo, blurry, low quality, artifact",
    "denoise_auto": True,
    "denoise_manual": 0.12,
    "face_denoise_scale": 0.7,
    "face_enhancement": True,
    "output_format": "png",
    "output_quality": 95,
    "steps": 4,  # Lightning LoRA allows 4 steps
    "cfg_scale": 7.0,
    "canny_low": 50,
    "canny_high": 150,
    "seed": -1,  # -1 = random
}

# Denoise scaling table (from architecture docs)
DENOISE_TABLE = {
    0.25: 0.08,   # 512x512
    1.0: 0.12,    # 1024x1024
    4.0: 0.15,    # 2048x2048
}

def _detect_device() -> str:
    """Detect the best available runtime device without shelling out."""
    try:
        import torch
        if torch.cuda.is_available():
            return "cuda"
    except Exception:
        pass
    return "cpu"


DEVICE = _detect_device()
